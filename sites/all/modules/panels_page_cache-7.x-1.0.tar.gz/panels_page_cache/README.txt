1. Enable 'Panels page cache' Module
2. Configure cache on Panels "Content -> Display Settings"
