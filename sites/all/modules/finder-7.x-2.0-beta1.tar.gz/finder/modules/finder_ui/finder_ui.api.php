<?php

/**
 * @file
 * Documents finder_ui's hooks for api reference.
 */

/**
 * Alter the Finder UI data array for a finder.
 */
function hook_finder_ui_alter(&$data, $finder) {
  // no example code
}

/**
 * Alter the Finder UI data array for an element.
 */
function hook_finder_ui_element_ui_alter(&$data, $finder, $finder_element_id) {
  // no example code
}
