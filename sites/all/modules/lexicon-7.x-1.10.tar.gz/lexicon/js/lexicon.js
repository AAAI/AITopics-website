(function($) {
  // Run the javascript on page load.
  $(document).ready(function() {
    // Enable the localscroll functionality
    $.localScroll();
  });
})(jQuery);