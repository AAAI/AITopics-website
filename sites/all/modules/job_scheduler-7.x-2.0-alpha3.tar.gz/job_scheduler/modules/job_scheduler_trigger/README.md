Drupal Module: Job Scheduler Trigger
====================================
Extension for Job Scheduler to create timed periodic triggers.

This module provides a simple UI to configure trigger name and crontab. We provide no actions, though actions created
by other modules can be set to be triggered with these timers.

Trigger type: job_scheduler
Hook names will be created on the fly for configured triggers as: job_scheduler_1, job_scheduler_2, etc...

Jose A. Reyero, http://www.developmentseed.org
