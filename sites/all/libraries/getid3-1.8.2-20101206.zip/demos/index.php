In this directory are a number of examples of how to use <a href="http://www.getid3.org">getID3()</a>.
If you don't know what to run, take a look at <a href="demo.browse.php">demo.browse.php</a>